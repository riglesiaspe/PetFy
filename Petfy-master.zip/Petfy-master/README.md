# Petfy
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

### Petfy is a Full Stack NodeJS web application built at HackUPC 2018

## Running

```
Git clone git@github.com:nikhilmufc7/Campy.git
```

```
cd to your cloned version
```

```
npm install
```

```
open a new tab in terminal for mongo instance and type

mongod
```

```
Back to our original tab

npm start or node app.js
```

```
open localhost:3000 in your browser
```



